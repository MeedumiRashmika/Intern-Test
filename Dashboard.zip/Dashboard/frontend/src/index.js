import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import { GoogleOAuthProvider } from '@react-oauth/google'; // Import GoogleOAuthProvider

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  // Wrap the app with GoogleOAuthProvider and pass the client ID
  <GoogleOAuthProvider clientId="YOUR_GOOGLE_CLIENT_ID">
    <App />
  </GoogleOAuthProvider>
);
