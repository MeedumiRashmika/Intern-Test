import React from 'react';
import { Link } from 'react-router-dom';

function Dashboard() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-8">
      <h1 className="mb-4 text-3xl">Admin Dashboard</h1>
      <Link to="/students" className="p-2 text-white bg-green-500 rounded">
        Manage Students
      </Link>
    </div>
  );
}

export default Dashboard;
