import React, { useState, useEffect } from "react";
import axios from "axios";

function Students() {
  const [students, setStudents] = useState([]);
  const [id, setId] = useState("");
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [image, setImage] = useState(null);
  const [status, setStatus] = useState("Active");
  const [editingStudentId, setEditingStudentId] = useState(null);

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/students");
      setStudents(res.data);
    } catch (error) {
      console.error("Error fetching students:", error);
    }
  };

  const handleFileChange = (e) => {
    setImage(e.target.files[0]);
  };

  const addStudent = async () => {
    if (!id || !name || !age || !image) {
      alert("Please fill all the fields");
      return;
    }

    const formData = new FormData();
    formData.append("id", id);
    formData.append("name", name);
    formData.append("age", age);
    formData.append("image", image);
    formData.append("status", status);

    const token = localStorage.getItem("token");
    if (!token) {
      alert("No token found. Please log in again.");
      return;
    }

    try {
      await axios.post("http://localhost:5000/api/students", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          "Authorization": `Bearer ${token}`,
        },
      });

      fetchStudents();
      clearForm();
    } catch (error) {
      console.error("Error adding student:", error);
      alert("An error occurred while adding the student.");
    }
  };

  const updateStudent = async () => {
    if (!name || !age) {
      alert("Please fill all the fields");
      return;
    }

    const formData = new FormData();
    formData.append("name", name);
    formData.append("age", age);
    if (image) formData.append("image", image);
    formData.append("status", status);

    const token = localStorage.getItem("token");
    if (!token) {
      alert("No token found. Please log in again.");
      return;
    }

    try {
      await axios.put(
        `http://localhost:5000/api/students/${editingStudentId}`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            "Authorization": `Bearer ${token}`,
          },
        }
      );

      fetchStudents();
      clearForm(); // Reset form fields
    } catch (error) {
      console.error("Error updating student", error);
      alert("An error occurred while updating the student.");
    }
  };

  const deleteStudent = async (studentId) => {
    const token = localStorage.getItem("token");
    if (!token) {
      alert("No token found. Please log in again.");
      return;
    }

    try {
      await axios.delete(`http://localhost:5000/api/students/${studentId}`, {
        headers: {
          "Authorization": `Bearer ${token}`,
        },
      });

      fetchStudents();
    } catch (error) {
      console.error("Error deleting student", error);
      alert("An error occurred while deleting the student.");
    }
  };

  const clearForm = () => {
    setId("");
    setName("");
    setAge("");
    setImage(null);
    setStatus("Active");
    setEditingStudentId(null); // Reset edit mode
  };

  return (
    <div className="p-8">
      <h2 className="mb-4 text-2xl ">
        {editingStudentId ? "Edit Student" : "Manage Students"}
      </h2>
      <div className="mb-4">
        <input
          type="text"
          placeholder="ID"
          value={id}
          onChange={(e) => setId(e.target.value)}
          className="p-2 mr-2 border"
          disabled={editingStudentId}
        />
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="p-2 mr-2 border"
        />
        <input
          type="text"
          placeholder="Age"
          value={age}
          onChange={(e) => setAge(e.target.value)}
          className="p-2 mr-2 border no-spinner"
        />
        <input type="file" onChange={handleFileChange} className="p-2 mr-2 border" />
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="p-2 mr-2 border"
        >
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
        </select>
        <button
          onClick={editingStudentId ? updateStudent : addStudent}
          className={`text-white p-2 rounded ${editingStudentId ? "bg-blue-500" : "bg-green-500"}`}
        >
          {editingStudentId ? "Update Student" : "Add Student"}
        </button>
      </div>

      <ul>
        {students.map((student) => (
          <li key={student._id} className="flex justify-between p-2 mb-2 border">
            <div>
              <img
                src={`http://localhost:5000/uploads/${student.image}`}
                alt={student.name}
                className="w-10 h-10 mr-2 rounded-full"
              />
              {student.name} ({student.age} years old) - {student.status}
            </div>
            <div className="flex">
              <button
                onClick={() => {
                  setEditingStudentId(student._id);
                  setId(student.id);
                  setName(student.name);
                  setAge(student.age);
                  setStatus(student.status);
                }}
                className="p-1 mr-2 text-white bg-green-400 rounded"
              >
                Edit
              </button>
              <button
                onClick={() => deleteStudent(student._id)}
                className="p-1 text-white bg-red-400 rounded"
              >
                Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Students;
