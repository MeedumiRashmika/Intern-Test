module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}", // This includes all your React files
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
